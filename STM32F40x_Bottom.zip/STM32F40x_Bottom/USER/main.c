#include "stm32f4xx.h"
#include "usart.h"
#include "delay.h"
#include "lcd.h"

#define KEY_DOWN          (GPIO_ReadInputData(GPIOG) & 0x00f0)
#define GPIOG_PIN_4to7    (GPIO_ReadInputData(GPIOG) & 0x00f0)

void GPIO_Config(void);
u8 KeyCheck(void);


int main(void)
{
	u8 num = 0;
	delay_init(168);
	GPIO_Config();
	while(1)
	{
		num = KeyCheck();
		Lcd_Set_Point(1,5);
		Lcd_Write_Data(num);
	}
}
void GPIO_Config(void)
{
	GPIO_InitTypeDef     GPIO_InitStructure;
	
	RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOG,ENABLE);
	
	GPIO_InitStructure.GPIO_Mode  = GPIO_Mode_OUT;
	GPIO_InitStructure.GPIO_OType = GPIO_OType_PP;
	GPIO_InitStructure.GPIO_Pin   = GPIO_Pin_0 | GPIO_Pin_1 | GPIO_Pin_2 | GPIO_Pin_3;
	GPIO_InitStructure.GPIO_PuPd  = GPIO_PuPd_UP;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_Init(GPIOG,&GPIO_InitStructure);
	
	GPIO_InitStructure.GPIO_Mode  = GPIO_Mode_IN;
	GPIO_InitStructure.GPIO_Pin   = GPIO_Pin_7 | GPIO_Pin_7 | GPIO_Pin_7 | GPIO_Pin_7;
	GPIO_InitStructure.GPIO_PuPd  = GPIO_PuPd_UP;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_Init(GPIOG,&GPIO_InitStructure);
	
	GPIO_SetBits(GPIOG,GPIO_Pin_0|GPIO_Pin_1|GPIO_Pin_2|GPIO_Pin_3);
	GPIO_ResetBits(GPIOG,GPIO_Pin_4|GPIO_Pin_5|GPIO_Pin_6|GPIO_Pin_7);
}
u8 KeyCheck(void)
{
	if(KEY_DOWN)
	{
		delay_ms(10);
		if(KEY_DOWN)
		{
			u8 result;
			GPIO_SetBits(GPIOG,GPIO_Pin_0);
			GPIO_ResetBits(GPIOG,GPIO_Pin_1|GPIO_Pin_2|GPIO_Pin_3);
			if(KEY_DOWN)
			{
				switch(GPIOG_PIN_4to7)
				{
					case (0x10) : result = 1; break; 
					case (0x20) : result = 5; break; 
					case (0x40) : result = 9; break; 
					case (0x80) : result = 13; break; 
				}
			}
			
			GPIO_SetBits(GPIOG,GPIO_Pin_1);
			GPIO_ResetBits(GPIOG,GPIO_Pin_0|GPIO_Pin_2|GPIO_Pin_3);
			if(KEY_DOWN)
			{
				switch(GPIOG_PIN_4to7)
				{
					case (0x10) : result = 2; break; 
					case (0x20) : result = 6; break; 
					case (0x40) : result = 10; break; 
					case (0x80) : result = 14; break; 
				}
			}
			
			GPIO_SetBits(GPIOG,GPIO_Pin_2);
			GPIO_ResetBits(GPIOG,GPIO_Pin_0|GPIO_Pin_1|GPIO_Pin_3);
			if(KEY_DOWN)
			{
				switch(GPIOG_PIN_4to7)
				{
					case (0x10) : result = 3; break; 
					case (0x20) : result = 7; break; 
					case (0x40) : result = 11; break; 
					case (0x80) : result = 15; break; 
				}
			}
			
			GPIO_SetBits(GPIOG,GPIO_Pin_3);
			GPIO_ResetBits(GPIOG,GPIO_Pin_0|GPIO_Pin_1|GPIO_Pin_2);
			if(KEY_DOWN)
			{
				switch(GPIOG_PIN_4to7)
				{
					case (0x10) : result = 4; break; 
					case (0x20) : result = 8; break; 
					case (0x40) : result = 12; break; 
					case (0x80) : result = 16; break; 
				}
			}
			return result;
		}
	}
	return 0;
}
