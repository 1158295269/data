#ifndef _LCD_H
#define _LCD_H

#include "stm32f4xx.h"

#define LCD_RS_Set           GPIO_SetBits(GPIOF,GPIO_Pin_0)
#define LCD_RS_ReSet         GPIO_ResetBits(GPIOF,GPIO_Pin_0)

#define LCD_RW_Set           GPIO_SetBits(GPIOF,GPIO_Pin_1)
#define LCD_RW_ReSet         GPIO_ResetBits(GPIOF,GPIO_Pin_1)

#define LCD_EN_Set           GPIO_SetBits(GPIOG,GPIO_Pin_15)
#define LCD_EN_ReSet         GPIO_ResetBits(GPIOG,GPIO_Pin_15)

#define LCD_Send_Data(x)     GPIO_Write(GPIOE, x)

void Lcd_GPIO_Config(void);
void Lcd_Write_Cmd(u8 cmd);
void Lcd_Write_Data(u8 dat);
void Lcd_Set_Point(u8 x,u8 y);
void Lcd_Send_Str(u8 x, u8 y, u8 *str);
void Lcd_Init(void);
void Lcd_Crl(void);

#endif /* _LCD_H  */

