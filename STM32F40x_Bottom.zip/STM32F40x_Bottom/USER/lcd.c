#include "lcd.h"
#include "delay.h"
#include "stdio.h"

void Lcd_GPIO_Config(void)
{
	GPIO_InitTypeDef    GPIO_InitStructure;
	RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOE | RCC_AHB1Periph_GPIOF | RCC_AHB1Periph_GPIOG,ENABLE);

	GPIO_InitStructure.GPIO_Mode  = GPIO_Mode_OUT;
	GPIO_InitStructure.GPIO_Pin   = GPIO_Pin_0 | GPIO_Pin_1 | GPIO_Pin_2 | GPIO_Pin_3 | GPIO_Pin_4 | GPIO_Pin_5 | GPIO_Pin_6 | GPIO_Pin_7;
	GPIO_InitStructure.GPIO_OType = GPIO_OType_PP;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_InitStructure.GPIO_PuPd  = GPIO_PuPd_UP;
	GPIO_Init(GPIOE,&GPIO_InitStructure);

  GPIO_InitStructure.GPIO_Mode  = GPIO_Mode_OUT;	
	GPIO_InitStructure.GPIO_Pin   = GPIO_Pin_0 | GPIO_Pin_1;
	GPIO_InitStructure.GPIO_OType = GPIO_OType_PP;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_InitStructure.GPIO_PuPd  = GPIO_PuPd_UP;
	GPIO_Init(GPIOF,&GPIO_InitStructure);

  GPIO_InitStructure.GPIO_Mode  = GPIO_Mode_OUT;
	GPIO_InitStructure.GPIO_Pin   = GPIO_Pin_15;
	GPIO_InitStructure.GPIO_OType = GPIO_OType_PP;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_InitStructure.GPIO_PuPd  = GPIO_PuPd_UP;GPIO_InitStructure.GPIO_Mode  = GPIO_Mode_OUT;
	GPIO_Init(GPIOG,&GPIO_InitStructure);
}
void Lcd_Write_Cmd(u8 cmd)
{
	LCD_RS_ReSet;
	delay_ms(1);
	LCD_RW_ReSet;
	delay_ms(1);
	LCD_Send_Data(cmd);
	delay_ms(1);
	LCD_EN_Set;
	delay_ms(1);
	LCD_EN_ReSet;
	delay_ms(1);
}
void Lcd_Write_Data(u8 dat)
{
	LCD_RS_Set;
	delay_ms(1);
	LCD_RW_ReSet;
	delay_ms(1);
	LCD_Send_Data(dat);
	delay_ms(1);
	LCD_EN_Set;
	delay_ms(1);
	LCD_EN_ReSet;
	delay_ms(1);
}
void Lcd_Crl(void)
{
	Lcd_Write_Cmd(0x01);
}
void Lcd_Set_Point(u8 x,u8 y)
{
	u8 addr;
	if(y == 0)
	{
		addr = 0x00 + x;
	}
	else
	{
		addr = 0x40 + x;
	}
	Lcd_Write_Cmd(addr | 0x80);
}
void Lcd_Send_Str(u8 x, u8 y, u8 *str)
{
	Lcd_Set_Point(x,y);
	while(*str != '\0')
	{
		Lcd_Write_Data(*str++);
	}
}
void Lcd_Init(void)
{
	Lcd_GPIO_Config();
	Lcd_Write_Cmd(0x38);	//16*2��ʾ��5*7����8λ���ݿ�
	Lcd_Write_Cmd(0x0c);	//����ʾ�����ر�
	Lcd_Write_Cmd(0x06);	//���ֲ�������ַ�Զ�+1
	Lcd_Write_Cmd(0x01);	//����
}

