#include "12864.h"
#include "font.h"

uint8_t LCD12864_OverTurn(uint8_t data)
{
	uint8_t i;
	uint8_t retval=0x00;
	
	for(i=0;i<8;i++)
	{
		retval|=((data>>i)&0x01)<<(7-i);
	}
	
	return retval;
}

void LCD12864_Writecmd(uint8_t cmd)
{
	//LCD12864_WaitReady();
	
	LCD12864_RS_CLS();	//ָ��
	LCD12864_RW_CLS();	 //д
	
	LCD12864_DataOutput(cmd);
	HAL_Delay(1);
	LCD12864_EN_SET();
	HAL_Delay(2);
	LCD12864_EN_CLS();
	HAL_Delay(1);
}

void LCD12864_Writedat(uint8_t data)
{
	//LCD12864_WaitReady();
	
	LCD12864_RS_SET();	//����
	LCD12864_RW_CLS();	 //д
	
	LCD12864_DataOutput(data);
	HAL_Delay(1);
	LCD12864_EN_SET();
	HAL_Delay(2);
	LCD12864_EN_CLS();
	HAL_Delay(1);
}


void LCD12864_SetCursor(uint16_t page,uint16_t column)
{
	LCD12864_Writecmd(PAGE_ADD+page);			//����ҳ��ַ
	LCD12864_Writecmd(COL_ADD+column);				//�����е�ַ
}

void LCD12864_CLS()
{
	LCD12864_Writecmd(0x01);
}

void hz_LCDDisp16(unsigned char page,unsigned char column,const unsigned char *hzk)
{
	unsigned char j=0,i=0;
	for(j=0;j<2;j++)
	{
		//LCD12864_Writecmd(PAGE_ADD+page+j);
		//LCD12864_Writecmd(COL_ADD+column);
		for(i=0;i<16;i++) 
		{
			LCD12864_SetCursor(page+j,column+i);
			LCD12864_Writedat(hzk[16*j+i]);			
		}
	}
}

void LCD12864_ShowChar(uint8_t page,uint8_t column,uint8_t chr,uint8_t size)
{
	uint8_t size1,size2,chr1,temp;
	uint8_t i;
	size1=size/8+((size%8)?1:0);
  size2=size1*(size/2);

	chr1=chr-' ';
	
	for(i=0;i<size2;i++)
	{
		if(size==16) temp=asc2_1608[chr1][i];
		else if(size==24) temp=asc2_2412[chr1][i];
		LCD12864_SetCursor(page+(i%size1),column+i/size1);
		LCD12864_Writedat(LCD12864_OverTurn(temp));
	}
}

void LCD12864_ShowString(uint8_t page,uint8_t column,uint8_t* str,uint8_t size)
{
		while((*str>=' ') && (*str<='~'))
		{
			LCD12864_ShowChar(page,column,*str,size);
			column+=size/2;
			if(column>64-size)
			{
				column=0;
				page+=2;
			}	
			str++;
	}
}
void LCD12864_Init()
{
	LCD12864_CS1_SET();
	LCD12864_CS2_SET();
	
	LCD12864_Writecmd(LCD_Off);
	LCD12864_Writecmd(0xc0);
	LCD12864_Writecmd(PAGE_ADD);
	LCD12864_Writecmd(COL_ADD);
	LCD12864_Writecmd(0x01);
	LCD12864_Writecmd(LCD_On);
}

