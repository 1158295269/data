#ifndef __12864_H
#define __12864_H

#include "gpio.h"
	
#define	PAGE_ADD	0xB8
#define COL_ADD 0x40
#define LCD_Off   0x3e
#define LCD_On    0x3f
	
#define LCD12864_RS_SET()		HAL_GPIO_WritePin(RS_GPIO_Port,RS_Pin,GPIO_PIN_SET)
#define LCD12864_RS_CLS()		HAL_GPIO_WritePin(RS_GPIO_Port,RS_Pin,GPIO_PIN_RESET)	

#define LCD12864_RW_SET()		HAL_GPIO_WritePin(RW_GPIO_Port,RW_Pin,GPIO_PIN_SET)
#define LCD12864_RW_CLS()		HAL_GPIO_WritePin(RW_GPIO_Port,RW_Pin,GPIO_PIN_RESET)

#define LCD12864_EN_SET()		HAL_GPIO_WritePin(EN_GPIO_Port,EN_Pin,GPIO_PIN_SET)		
#define LCD12864_EN_CLS()		HAL_GPIO_WritePin(EN_GPIO_Port,EN_Pin,GPIO_PIN_RESET)

#define LCD12864_CS1_SET()	HAL_GPIO_WritePin(CS1_GPIO_Port,CS1_Pin,GPIO_PIN_SET)		
#define LCD12864_CS1_CLS()	HAL_GPIO_WritePin(CS1_GPIO_Port,CS1_Pin,GPIO_PIN_RESET)

#define LCD12864_CS2_SET()	HAL_GPIO_WritePin(CS2_GPIO_Port,CS2_Pin,GPIO_PIN_SET)
#define LCD12864_CS2_CLS()	HAL_GPIO_WritePin(CS2_GPIO_Port,CS2_Pin,GPIO_PIN_RESET)

#define LCD12864_DataOutput(x)	GPIOE->ODR = x
#define LCD12864_DataInput()	GPIOE->ODR	


void LCD12864_Writecmd(uint8_t cmd);
void LCD12864_Writedat(uint8_t data);
void LCD12864_SetCursor(uint16_t page,uint16_t column);
void LCD12864_CLS(void);
void LCD12864_Init(void);
uint8_t LCD12864_OverTurn(uint8_t data);
void LCD12864_ShowChar(uint8_t page,uint8_t column,uint8_t chr,uint8_t size);
void LCD12864_ShowString(uint8_t page,uint8_t column,uint8_t* str,uint8_t size);
void hz_LCDDisp16(unsigned char page,unsigned char column,const unsigned char *hzk);

#endif

